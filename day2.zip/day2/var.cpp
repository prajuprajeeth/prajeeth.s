#include<iostream>
using namespace std;

int main() {
    // Integer variables
    int num1, num2;
    
    // Floating point variables 
    float decimal1 = 3.14;
    double decimal2 = 3.14159;
    
    // Character variables
    char letter = 'A';l
    char symbol = '$';
    
    // Boolean variable
    bool isTrue = true;
    
    // String variable
    string text = "Hello";

    // Print out the values to demonstrate
    cout << "num1: " << num1 << ", num2: " << num2 << endl;
    cout << "decimal1: " << decimal1 << ", decimal2: " << decimal2 << endl;
    cout << "letter: " << letter << ", symbol: " << symbol << endl;
    cout << "isTrue: " << isTrue << endl;
    cout << "text: " << text << endl;

    return 0;
}
