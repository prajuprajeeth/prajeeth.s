#include<iostream>
using namespace std;
int main()
{
    int age=0;
    float marks=0;
    char gender;
    string name="nihar k naik";
    cout<<"enter a student age:"<<endl;
    cin>>age;
    cout<<"enter a student marks:"<<endl;
    cin>>marks;
    cout<<"enter a student gender:"<<endl;
    cin>>gender;
    cout<<"enter a student name:"<<endl;
    cin>>name;
    cout<<"enter student details:"<<endl;
    cout<<"name:"<<name<<endl;
    cout<<"gender:"<<gender<<endl;
    cout<<"age:"<<age<<endl;
    cout<<"marks:"<<marks<<endl;
}






